# Chuck Norris Database API

http://www.icndb.com/api/