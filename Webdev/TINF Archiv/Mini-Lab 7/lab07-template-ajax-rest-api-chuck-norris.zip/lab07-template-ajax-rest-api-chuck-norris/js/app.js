$(document).ready(function() {

  $('#btn-random').click(() => {
    loadJokeFromApi();
  });

});

function loadJokeFromApi() {
  // done
  let address = 'https://api.chucknorris.io/jokes/random';
  $.getJSON(address, (data, status) => {
    let s = data.value;
    $('#joke').html(s);
  });
}

