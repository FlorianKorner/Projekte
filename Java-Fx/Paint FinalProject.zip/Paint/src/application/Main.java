package application;
	
import java.io.FileInputStream;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	private Stage primaryStage;
	@Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        FXMLLoader fxloader = new FXMLLoader(this.getClass().getResource("graphical interface.fxml"));

        try {
            primaryStage.setScene(new Scene(fxloader.load()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        primaryStage.getIcons().add(new Image(this.getClass().getResourceAsStream("/res/pics/icon.jpg")));
        
        primaryStage.setTitle("Paint by Florian K�rner");
        primaryStage.show();
    }
	
	
	public Stage getPrimaryStage() {
		return primaryStage;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
